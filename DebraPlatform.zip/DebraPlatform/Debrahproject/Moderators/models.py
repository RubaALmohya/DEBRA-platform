from django.db import models
from django.contrib.auth.models import User
# Create your models here.
CHOICE_account_type = ((1, "Individual"), (2, "Expert"))
CHOICE_GENDER = ((1, 'Male'), (2, 'Female'))

class RegisterModel(models.Model):
    name = models.CharField(max_length=100)
    gender = models.IntegerField(choices=CHOICE_GENDER)
    account_type = models.IntegerField(choices=CHOICE_account_type)
    birthday = models.DateField()
    user = models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return self.name