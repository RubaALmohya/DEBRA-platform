from django.contrib import admin
from .models import RegisterModel


# Register your models here.
admin.site.register(RegisterModel)
