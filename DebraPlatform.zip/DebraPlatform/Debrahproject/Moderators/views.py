from django.shortcuts import render
from django.contrib.auth.models import User, Group
from django.contrib.auth import authenticate
from rest_framework.decorators import api_view,authentication_classes, permission_classes
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import AccessToken
from .serializers import RegisterSerializer , UserGropes
from .models import RegisterModel
# Create your views here.
@api_view(['GET'])
def Instructions(request:Request):
    DebrahInstructions = {"Instructions:":"Your reading of these instructions obliges you to abide by them,"
                                          "and if you violate any of these instructions,"
                                          "you will be exposed to legal issues",
                          "1.":"Respect users and experts",
                          "2.":"The information provided by the user is correct",
                          "3.":"Do not create more than one account",
                          "4.":"The legal age of the user"}

    return Response(DebrahInstructions)

@api_view(['POST'])
def UserRegister(request:Request):
    """
     Function User Registration: to create and save a new user
     """
    NewUser = RegisterSerializer(data=request.data)
    if NewUser.is_valid():
        NewMembers = User.objects.create_user(**NewUser.data)
        NewMembers.save()
        msg = {"message": "created user successfuly"}
        return Response(msg)

    else:
        print(NewUser.errors)
        msg = {"message": "Couldn't create member"}
        return Response(msg)


@api_view(['POST'])
def UserLogin(request:Request):

    """
    Function user login: check whether the username and password are correct and make sure that the user is already there,
        and give him the token.
    """

    if 'username' in request.data and 'password' in request.data:
        Member = authenticate(request, username = request.data['username'], password=request.data['password'])

        if Member is not None:
            token = AccessToken.for_user(Member)
            MemberData = {"message":"your token is ready  :) ","token" : str(token)}
            return Response(MemberData)

    return Response({"msg" : "please provide your username and password"}, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
@authentication_classes([JWTAuthentication])
def UserSetting(request:Request):

    """
    User settings function: very important because the idea here is that when the user sets his account settings,
         this function sets him directly in the group that suits him to give him directly the permissions and permissions that fits his group.
    """
    if not request.user.is_authenticated:
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    user_sitting= UserGropes(data=request.data)

    if user_sitting.is_valid():
       if request.data['account_type'] == 1:
           group = Group.objects.get(name="Individuals")
           request.user.groups.add(group)

       elif request.data['account_type'] == 2:
           group = Group.objects.get(name="Experts")
           request.user.groups.add(group)

       user_sitting.save()
       usersitting = {
           "message": "Created setting Successfully" ,
           "user setting": user_sitting.data
       }
       return Response(usersitting)

    else:
       print(user_sitting.errors)
       usersitting = {"msg" : "couldn't create your setting"}
       return Response(usersitting ,status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def listAllUsers(request : Request):

    """
    List all users function: Displays all users
    """
    users = RegisterModel.objects.all()
    userslist = {"msg": "List of All users",
                 "users": UserGropes(instance=users, many=True).data}
    return Response(userslist)

@api_view(['GET'])
def listExperts(request : Request):
    """
    Expert listing function: Displays all experts only
    """
    experts = RegisterModel.objects.filter(account_type=2)
    expertslist = {"msg": "List of experts",
                 "experts": UserGropes(instance=experts, many=True).data}
    return Response(expertslist)

@api_view(['GET'])
def listUsers(request : Request):

    """Individuals users listing function: Displays all Individuals only"""

    users = RegisterModel.objects.filter(account_type=1)
    userslist = {"msg": "List of  users",
                 "users": UserGropes(instance=users, many=True).data}
    return Response(userslist)



@api_view(['PUT'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def UpdateUsers(request : Request, user_id):

    """This function: Allows the logged in user to modify their settings"""

    if not request.user.is_authenticated:
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    user_edit = RegisterModel.objects.get(id=user_id)
    if user_edit.user.id == request.user.id:
        update_user = UserGropes(instance=user_edit, data=request.data)

        if update_user.is_valid():
            update_user.save()
            UpdateData = { "massage" : "updated successefully"}
            return Response(UpdateData)

        else:
            print(update_user.errors)
            UpdateData = {"massage": "bad request, cannot update"}
            return Response(UpdateData, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def deleteUsers(request: Request, user_id):

    """User deletion function: Allows the current user to delete his account"""

    if not request.user.is_authenticated:
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data.update(user=request.user.id)
    user_delete = RegisterModel.objects.get(id=user_id)

    if user_delete.user.id == request.user.id:
        user_delete.delete()

        DeleteData = {"massage" : "Deleted Successfully"}
        return Response(DeleteData)