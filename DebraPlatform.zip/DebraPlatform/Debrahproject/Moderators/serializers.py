from rest_framework import serializers
from django.contrib.auth.models import User
from .models import RegisterModel


class RegisterSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = ['username',
                  'email',
                  'password']


class UserGropes(serializers.ModelSerializer):
    class Meta:
        model = RegisterModel
        fields = '__all__'


