from django.urls import path
from . import views



urlpatterns = [
    path("instructions/",views.Instructions,name="Instructions"),
    path("register", views.UserRegister, name="User Register"),
    path("login", views.UserLogin, name="User Login "),
    path("setting",views.UserSetting,name="User Setting"),
    path("show",views.listAllUsers, name="List of all Users"),
    path("users", views.listUsers, name="List of Individual"),
    path("experts", views.listExperts, name="List of Experts"),
    path('update/<user_id>',views.UpdateUsers,name="Update Users Information"),
    path('delete/<user_id>',views.deleteUsers,name="Delete User Account")
]