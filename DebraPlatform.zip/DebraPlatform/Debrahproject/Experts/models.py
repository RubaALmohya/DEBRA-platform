from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

# Create your models here.
class ExpertModel(models.Model):
    name = models.CharField(max_length=100)
    domain = models.CharField(max_length=200)
    Services = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self):
        return self.name


SECTIONS = ((1, "Applecation"), (2, "Website"))


class AuctionModel(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    field = models.CharField(max_length=100)
    type = models.IntegerField(choices=SECTIONS)
    price = models.IntegerField()
    expert = models.ForeignKey(ExpertModel,on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class AddAuctionModel(models.Model):

    auction = models.ForeignKey(AuctionModel, on_delete=models.CASCADE)
    start_time = models.TimeField(auto_now_add=True)#  so it will add the current time at creation!
    end_time = models.TimeField() # start_time +15
    price = models.IntegerField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.auction.name

    def is_done(self):
        end_time = self.end_time
        time_now = datetime.now().time()
        if time_now < end_time:
            return False
        return True
