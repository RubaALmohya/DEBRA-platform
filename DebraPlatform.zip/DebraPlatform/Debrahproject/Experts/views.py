from datetime import datetime, timedelta
from django.http import JsonResponse
from rest_framework.decorators import api_view, authentication_classes,permission_classes
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth.models import  User
from .models import ExpertModel, AuctionModel, AddAuctionModel
from .serializers import ExpetsSerializers , AuctionModelSerializers

# Create your views here.
@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def AddExpert(request : Request):

    """
    Add Expert function : This function only allows experts to add their own information such as the name,
            their services and the field of this expert
    """

    if not request.user.is_authenticated or not request.user.has_perm('Experts.add_expertmodel'):
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    NewExpert = ExpetsSerializers(data=request.data)

    if NewExpert.is_valid():
        NewExpert.save()
        ExpertData = {"massage" : "Expert Created Successfully", "Project":NewExpert.data}
        return Response(ExpertData)

    else:
        print(NewExpert.errors)
        ExpertData = {"massage" : " couldn't create "}
        return Response(ExpertData , status=status.HTTP_400_BAD_REQUEST )


@api_view(['PUT'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def EditeExpert(request : Request ,expert_id):

    """
    This function only allows experts to modify their information that was added through AddExpert()
    """
    if not request.user.is_authenticated or not request.user.has_perm('Experts.change_expertmodel'):
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    expert_info = ExpertModel.objects.get(id=expert_id)
    if expert_info.user.id == request.user.id:

        EditExpertInfo = ExpetsSerializers(instance=expert_info,data=request.data)

        if EditExpertInfo.is_valid():
            EditExpertInfo.save()
            ExpertData = {"masssage" : " Edit Successefully"}
            return Response(ExpertData)

        else:
            print(EditExpertInfo.errors)
            ExpertData = {"massage": "bad request, cannot update"}
            return Response(ExpertData,status=status.HTTP_400_BAD_REQUEST)



@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def AddAuction(request : Request):

    """Here in this function the expert is allowed to add information about a ready-made project that he wants to auction and sell to users"""

    if not request.user.is_authenticated or not request.user.has_perm('Experts.add_auctionmodel'):
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    NewAuction = AuctionModelSerializers(data=request.data)

    if NewAuction.is_valid():
        NewAuction.save()
        AuctionData = {"massage":"Created Successfully" , "Auction":NewAuction.data}
        return Response(AuctionData)

    else:
        print(NewAuction.errors)
        AuctionData = {"massage": "couldn't create"}
        return Response(AuctionData, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def EditAuction(request : Request,expert_id):

    """
    This function only allows experts to modify their information that was added through AddAuction()
    """
    if not request.user.is_authenticated or not request.user.has_perm('Experts.change_auctionmodel'):
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    expert_info = AuctionModel.objects.get(id=expert_id)
    EditAuctionInfo = AuctionModelSerializers(instance=expert_info,data=request.data)

    if EditAuctionInfo.is_valid():
        EditAuctionInfo.save()
        AuctionData = {"masssage" : " Edit Successefully"}
        return Response(AuctionData)

    else:
        print(EditAuctionInfo.errors)
        AuctionData = {"massage": "bad request, cannot update"}
        return Response(AuctionData,status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def listExpertAuction(request : Request):

    """
   this function : Only experts are allowed to view all the projects that will be bidding in auction
    """
    if not request.user.is_authenticated or not request.user.has_perm('Experts.view_auctionmodel'):
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    """
    List all users function: Displays all users
    """
    expet = AuctionModel.objects.all()
    ExpetAuction = {"msg": "List of All expert ",
                 "Auction": AuctionModelSerializers(instance=expet, many=True).data}
    return Response(ExpetAuction)





@api_view(["POST"])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def new_auction_add(request):
    """This function is to start the auction process for the expert project, from which the start and end time of the auction is determined."""
    if not request.user.is_authenticated:
         return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    auction_id = request.data.get("auction_id")
    price = request.data.get("price")
    print(auction_id, price)

    get_auction = AuctionModel.objects.get(id=auction_id)
    all_add = AddAuctionModel.objects.filter(auction=get_auction)
    print(all_add)

    if len(all_add) >= 1:
        return JsonResponse({"ok": "false", "error": "auction already started"})

    # user = request.user
    user = User.objects.all()[0]
    end_time = datetime.now() + timedelta(minutes=15)
    new_add = AddAuctionModel.objects.create(auction=get_auction,
                                             user=user,
                                             price=price,
                                             end_time=end_time.time())
    return JsonResponse({"ok": "true"})

@api_view(["POST"])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def update_auction_bid(request):

    """
    This function is related to the auction start process: they update the price,
    taking into account that it does not add after the expiry of the time and only adds a larger number than what has been offered.
    """

    if not request.user.is_authenticated:
        return Response("Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    auction_id = request.data.get("auction_id")
    price = request.data.get("price")
    print(auction_id, price)

    get_auction = AuctionModel.objects.get(id=auction_id)
    user = User.objects.all()[0]
    new_add = AddAuctionModel.objects.filter(auction=get_auction)[0]

    if new_add.is_done():
        return JsonResponse({"ok": "false", "error": "auction time is over"})

    if new_add.price >= int(price):
        return JsonResponse({"ok": "false", "error": "someone already bid higher than that"})

    new_add.price = price
    new_add.user = user
    new_add.save()

    return JsonResponse({"ok": "true"})






