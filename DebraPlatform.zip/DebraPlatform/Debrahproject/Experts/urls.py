from django.urls import path
from . import views

app_name = "weather"

urlpatterns = [
    path("add/", views.AddExpert, name="Add Expert"),
    path("edit/<expert_id>", views.EditeExpert, name="Edit Expert Information"),
    path("add_auction/", views.AddAuction),
    path("edit_auction/<expert_id>", views.EditAuction),
    path("show_expert_auction/",views.listExpertAuction),
    path("start_auction/", views.new_auction_add),
    path("update_auction/", views.update_auction_bid),
]
