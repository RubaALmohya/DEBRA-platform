
from django.contrib import admin
from .models import ExpertModel , AuctionModel,AddAuctionModel


# Register your models here.
admin.site.register(ExpertModel)
admin.site.register(AuctionModel)
admin.site.register(AddAuctionModel)
