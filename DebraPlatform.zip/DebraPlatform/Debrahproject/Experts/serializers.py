from rest_framework import serializers
from .models import ExpertModel , AuctionModel

class ExpetsSerializers(serializers.ModelSerializer):

    class Meta:
        model = ExpertModel
        fields = '__all__'


class AuctionModelSerializers(serializers.ModelSerializer):
    class Meta:
        model = AuctionModel
        fields = '__all__'