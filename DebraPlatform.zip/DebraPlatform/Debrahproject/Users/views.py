from django.shortcuts import render
from rest_framework.decorators import api_view,authentication_classes, permission_classes
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework.permissions import IsAuthenticated
from .models import UserProject , DealModel
from .serializers import UserProjectSerializers ,DealProjectSerializers
import jwt
import requests
import json
from time import time

# Create your views here.
@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def AddProject(request : Request):
    """Add project function: Only individual users are allowed, search can add project idea they want experts to implement"""

    if not request.user.is_authenticated :
        return Response("Sorry !! Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    NewProject = UserProjectSerializers(data=request.data)

    if NewProject.is_valid():
        NewProject.save()
        ProjectData = {"massage" : "Project Created Successfully", "Project":NewProject.data}
        return Response(ProjectData)

    else:
        print(NewProject.errors)
        ProjectData = {"masssage" : "Project couldn't create "}
        return Response(ProjectData , status=status.HTTP_400_BAD_REQUEST )

@api_view(['PATCH'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def EditeProject(request : Request ,project_id):

    """Edit project function: Only individual users are allowed, they can modify the project idea they want experts to implement """

    if not request.user.is_authenticated:
        return Response("Sorry !! Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    project = UserProject.objects.get(id=project_id)

    UpdateProject = UserProjectSerializers(instance=project,data=request.data)
    if UpdateProject.is_valid():
        UpdateProject.save()
        ProjectData = {"masssage" : "Project Updated Successefully"}
        return Response(ProjectData)

    else:
        print(UpdateProject.errors)
        ProjectData = {"massage": "bad request, cannot update"}
        return Response(ProjectData,status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def ListProject(request:Request ):

    """Project list function: Only individual users with permission, are allowed to view all projects"""

    if not request.user.is_authenticated :
        return Response("Sorry !! Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    Projects = UserProject.objects.all()
    ProjectData = {"massage" : "Projects List :","projects":UserProjectSerializers(instance=Projects,many=True).data}
    return Response(ProjectData)

@api_view(['DELETE'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def ProjectDrop(request:Request,project_id):
    """Project delete function: only individual users have permission, the user is allowed to delete their own project"""
    if not request.user.is_authenticated :
        return Response("Sorry !! Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    Project = UserProject.objects.get(id=project_id)

    if Project.user.id == request.user.id:
        Project.delete()
        ProjectData = {"massage":"Project Deleted Successfully"}
        return Response(ProjectData)

@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def DealProject(request : Request,project_id):

    """ The function of the project deal: here the experts send their approval to do the idea of the user. """

    if not request.user.is_authenticated:
        return Response("Sorry !! Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    request.data["user"] = request.user.id
    Project = UserProject.objects.get(id=project_id)
    requests = DealProjectSerializers(instance=Project,data=request.data)
    if requests.is_valid():
        if request.data['deal_requests'] == "True":
            requests.save()
            DealData = {
                    "message": "Created request Successfully",
                    "Deal Request": request.data
                }
            return Response(DealData)

    else:
        print(requests.errors)
        DealData = {"msg": "couldn't add your request"}
        return Response(DealData, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
def ListDeals(request : Request):

    """Deal list function: Shows us all deals"""

    if not request.user.is_authenticated:
        return Response("Sorry !! Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    deals = DealModel.objects.all()
    DealsData = {"massage": "Deals List :", "Requests": DealProjectSerializers(instance=deals, many=True).data}
    return Response(DealsData)

#zoom info
API_KEY = 'azxlmUjxRpe2Bc80D4wcjw'
API_SEC = 'sBlT6qTFTOww04cFYx6IGula2hoEaeaYE8H3'

# my id in zoom
userId = 'xhkQgI5OT1SOpABdxZmXWA'

# create a function to generate a token using the pyjwt library
def generateToken():
    token = jwt.encode(
        {'iss': API_KEY, 'exp': time() + 5000},
        API_SEC,
        algorithm='HS256'
    )
    return token
    # send a request with headers including a token

#fetching zoom meeting info now of the user,
@api_view(['GET'])
def getUsers(request : Request):
    """This is a MUST to get my ID on Zoom"""

    headers = {'authorization': 'Bearer %s' % generateToken(),
               'content-type': 'application/json'}

    r = requests.get('https://api.zoom.us/v2/users/', headers=headers)
    UserID = {"massage" :"fetching zoom meeting info now of the user ...", "ID":r}
    return Response(UserID)



meetingdetails = {"topic": "The title of your zoom meeting",
                  "type": 2,
                  "start_time": "2019-06-14T10: 21: 57",
                  "duration": "45",
                  "timezone": "Europe/Madrid",
                  "agenda": "test",

                  "recurrence": {"type": 1,
                                 "repeat_interval": 1
                                 },
                  "settings": {"host_video": "true",
                               "participant_video": "true",
                               "join_before_host": "False",
                               "mute_upon_entry": "False",
                               "watermark": "true",
                               "audio": "voip",
                               "auto_recording": "cloud"
                               }
                  }
@api_view(['GET'])
@authentication_classes([JWTAuthentication])
def createMeeting(request : Request ):

    """This function is to create a meeting in Zoom Live, the objective of which is that after the individual user of
    the expert is selected they are gathered in a meeting to discuss and follow up on the project"""

    if not request.user.is_authenticated:
        return Response("Sorry !! Not Allowed", status=status.HTTP_400_BAD_REQUEST)

    headers = {'authorization': 'Bearer %s' % generateToken(),
                   'content-type': 'application/json'}
    r = requests.post( f'https://api.zoom.us/v2/users/{userId}/meetings', headers=headers, data=json.dumps(meetingdetails))
    ZoomMeeting ={"massage":"creating zoom meeting" , "LINK": r.text}
    return Response(ZoomMeeting)

