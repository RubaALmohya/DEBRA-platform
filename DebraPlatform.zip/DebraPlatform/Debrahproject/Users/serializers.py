from rest_framework import serializers
from .models import   UserProject,DealModel

class UserProjectSerializers(serializers.ModelSerializer):

    class Meta:
        model = UserProject
        fields = '__all__'



class DealProjectSerializers(serializers.ModelSerializer):
    class Meta:
        model = DealModel
        fields = '__all__'