
from django.contrib import admin
from .models import UserProject , DealModel


# Register your models here.
admin.site.register(UserProject)
admin.site.register(DealModel)
