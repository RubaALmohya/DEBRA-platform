from django.urls import path
from . import views

urlpatterns = [
    path("add/", views.AddProject, name="Add New Project"),
    path("edit/<project_id>",views.EditeProject,name="Edit Project"),
    path("show/",views.ListProject,name="List of All Projects"),
    path("drop/<project_id>",views.ProjectDrop,name="Drop The Project"),
    path('deal/<project_id>',views.DealProject),
    path('deal/request/',views.ListDeals),
    path("getUser/" , views.getUsers),
    path("create/",views.createMeeting)
]