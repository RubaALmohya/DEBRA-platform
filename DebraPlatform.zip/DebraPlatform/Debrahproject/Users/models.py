from django.db import models
from django.contrib.auth.models import User
from Experts.models import ExpertModel


SECTIONS = ((1, "Applecation"), (2, "Website"))
# Create your models here.
class UserProject(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    deadline = models.DateField()
    amount = models.IntegerField()
    section = models.IntegerField(choices=SECTIONS)
    user = models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return self.title

class DealModel(models.Model):
    project = models.ForeignKey(UserProject , on_delete=models.CASCADE)
    experts = models.ForeignKey(ExpertModel, on_delete=models.CASCADE)
    deal_requests = models.BooleanField()

